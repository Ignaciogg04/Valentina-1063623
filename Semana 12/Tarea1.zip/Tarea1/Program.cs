﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TrianguloRectangulo triangulorectangulo = new TrianguloRectangulo();

            Console.WriteLine("Cuál es el cateto A?");
            double CatetoA = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Cuál es el ángulo opuesto del cateto A?");
            double OpuestoA = Convert.ToDouble(Console.ReadLine());

            triangulorectangulo.Catetos(CatetoA, OpuestoA);
            triangulorectangulo.ObtenerDatos();

            Console.ReadKey();
        }
    }
}