﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea
{
    internal class TrianguloRectangulo
    {
        private double catetoA;
        private double anguloOpuestoA;

        public void Catetos(double CatetoA, double AnguloOpuestoA)
        {
            this.catetoA = CatetoA;
            this.anguloOpuestoA = AnguloOpuestoA * (Math.PI / 180);
        }
        public double ObtenerCatetoA()
        {
            return catetoA;
        }
        public double ObtenerCatetoB()
        {
            return catetoA / Math.Tan(anguloOpuestoA);
        }
        public double ObtenerHipotenusa()
        {
            return catetoA / Math.Sin(anguloOpuestoA);
        }
        public double ObteneranguloOpuestoA()
        {
            return anguloOpuestoA * (180 / Math.PI);
        }
        public double ObteneranguloOpuestoB()
        {
            return 90 - ObteneranguloOpuestoA();
        }
        public double ObtenerArea()
        {
            return ((ObtenerCatetoA()) * (ObtenerCatetoB()) / 2);
        }
        public void ObtenerDatos()
        {
            Console.WriteLine("El cateto A es: " + ObtenerCatetoA().ToString());
            Console.WriteLine("El cateto B es: " + ObtenerCatetoB().ToString());
            Console.WriteLine("La hipotenusa es: " + ObtenerHipotenusa().ToString());
            Console.WriteLine("El angulo opuesto de A es: " + ObteneranguloOpuestoA().ToString());
            Console.WriteLine("El angulo opuesto de B es: " + ObteneranguloOpuestoB().ToString());
            Console.WriteLine("El area del triangulo es: " + ObtenerArea().ToString());
        }
    }
}
